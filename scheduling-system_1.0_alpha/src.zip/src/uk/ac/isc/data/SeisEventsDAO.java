
package uk.ac.isc.data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;


/**
 *
 * @author hui
 * Data Access Object for getting events, allocation, block and assignment info
 * 
 */
public class SeisEventsDAO {
    
    /**
     * Loading user name, password and scheme from system environment
     */
    static {         
        Map<String, String> env = System.getenv();
        url = "jdbc:postgresql://"+env.get("PGHOSTADDR")+":"+env.get("PGPORT")+"/"+env.get("PGDATABASE");
        user = env.get("PGUSER");
        password = env.get("PGPASSWORD"); 
        //url = "jdbc:postgresql://127.0.0.1:5432/isc";
        //user = "hui";
        //password = "njustga";
    }
    
    /**
     * variables for the database access
     */
    private static final String url; 
    private static final String user; 
    private static final String password; 
    
    /**
     * Get the start Date of all the events
     * @return startDate
     */
    public static Date retrieveStartDate()
    {
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date startDate = null;
        
        String query = "SELECT MIN(h.day)" +
                " FROM event e, hypocenter h" +
                " WHERE e.prime_hyp = h.hypid" +
                " AND h.isc_evid = e.evid AND e.banished IS NULL AND e.ready IS NOT NULL;";
        
        try {
            con = DriverManager.getConnection(url, user, password);
            st = con.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                                
                try {
                   // System.out.println(rs.getString(1));
                   startDate = df.parse(rs.getString(1));
                } catch (ParseException e)
                {
                    return null;
                }
            }

        } catch (SQLException ex) {
            return null;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (con != null) {
                    con.close();
                }

            } catch (SQLException ex) {
                
                return null;
            }
        }
        
        return startDate;
        
    }
         
    /**
     * Get the last Date of all the events
     * @return 
     */
    public static Date retrieveEndDate()
    {
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date endDate = null;
        
        String query = "SELECT MAX(h.day)" +
                " FROM event e, hypocenter h" +
                " WHERE e.prime_hyp = h.hypid" +
                " AND h.isc_evid = e.evid AND e.banished IS NULL AND e.ready IS NOT NULL;";
        
        try {
            con = DriverManager.getConnection(url, user, password);
            st = con.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                                
                try {
                   // System.out.println(rs.getString(1));
                   endDate = df.parse(rs.getString(1));
                } catch (ParseException e)
                {
                    return null;
                }
            }

        } catch (SQLException ex) {
            return null;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (con != null) {
                    con.close();
                }

            } catch (SQLException ex) {
                
                return null;
            }
        }
        
        return endDate;       
    }
    
    /**
     * retrieve all events in the schema first
     * @param seisEvents
     * @return 
     */
    public static boolean retrieveAllEvents(ArrayList<SeisEvent> seisEvents) {
         
        //clear the memory of seisEvent in order to reload events
        seisEvents.clear();
        
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                
        String query = "SELECT e.evid, h.day, h.lat, h.lon" +
                " FROM event e, hypocenter h" +
                " WHERE e.prime_hyp = h.hypid" +
                " AND h.isc_evid = e.evid AND e.banished IS NULL AND e.ready IS NOT NULL" +
                " ORDER BY h.day ASC;";

        try {
            con = DriverManager.getConnection(url, user, password);
            st = con.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                
                SeisEvent tmp = new SeisEvent(rs.getInt(1));
                Date dd = null;
                
                try {
                   dd = df.parse(rs.getString(2));
                } catch (ParseException e)
                {
                    return false;
                }

                tmp.setOrigTime(dd);
                tmp.setLat(rs.getDouble(3));
                tmp.setLon(rs.getDouble(4));
                
                seisEvents.add(tmp);
            }

        } catch (SQLException ex) {
            return false;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (con != null) {
                    con.close();
                }

            } catch (SQLException ex) {
                
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * @obsolete
     * @param seisEvents to save all unallocated events to show on timeline and map
     * @return success or not
     */
    public static boolean retrieveUnallocEvents(ArrayList<SeisEvent> seisEvents) {
         
        //clear the memory of seisEvent in order to reload events
        seisEvents.clear();
        
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        
        
        String query = "SELECT e.evid, h.day, h.lat, h.lon" +
                " FROM event e, hypocenter h" +
                " WHERE e.prime_hyp = h.hypid" +
                " AND h.isc_evid = e.evid AND e.banished IS NULL AND e.ready IS NOT NULL" +
                " AND NOT EXISTS ( SELECT a.evid FROM allocation a WHERE a.evid = e.evid )" +
                " ORDER BY h.day ASC;";

        try {
            con = DriverManager.getConnection(url, user, password);
            st = con.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                
                SeisEvent tmp = new SeisEvent(rs.getInt(1));
                Date dd = null;
                
                try {
                   dd = df.parse(rs.getString(2));
                } catch (ParseException e)
                {
                    return false;
                }

                tmp.setOrigTime(dd);
                tmp.setLat(rs.getDouble(3));
                tmp.setLon(rs.getDouble(4));
                
                seisEvents.add(tmp);
            }

        } catch (SQLException ex) {
            return false;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (con != null) {
                    con.close();
                }

            } catch (SQLException ex) {
                
                return false;
            }
        }
        
        return true;
    }
    
    /**
     *
     * @param evSet
     * @return
     */
    public static boolean retrieveAllocatedEvID(HashMap<Integer,Integer> evSet) {
                
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        
        String query = "SELECT ea.evid, b.block_id" +
                " FROM event e, hypocenter h, event_allocation ea, block_allocation b" +
                " WHERE e.prime_hyp = h.hypid" +
                " AND h.isc_evid = e.evid AND e.banished IS NULL AND e.ready IS NOT NULL" +
                " AND ea.evid = e.evid AND b.id = ea.block_allocation_id" +
                " ORDER BY h.day ASC;";

        try {
            con = DriverManager.getConnection(url, user, password);
            st = con.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                
                evSet.put(rs.getInt(1),rs.getInt(2));
            }

        } catch (SQLException ex) {
            return false;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (con != null) {
                    con.close();
                }

            } catch (SQLException ex) {
                
                return false;
            }
        }
        
        return true;
    }
    
     /**
     *
     * @param blockID block ID number 
     * @param seisEvents to save all unallocated events to show on timeline and map
     * @return success or not
     */
    public static boolean retrieveBlockEvents(int blockID, ArrayList<SeisEvent> seisEvents) {
         
        //clear the memory of seisEvent in order to reload events
        seisEvents.clear();
        
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        
        String query = "SELECT e.evid, h.day, h.lat, h.lon" +
                " FROM event e, hypocenter h, allocation a" +
                " WHERE e.prime_hyp = h.hypid" +
                " AND h.isc_evid = e.evid AND e.banished IS NULL AND e.ready IS NOT NULL" +
                " AND a.evid = e.evid AND a.block_id = " + blockID +
                " ORDER BY h.day ASC;";

        try {
            con = DriverManager.getConnection(url, user, password);
            st = con.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                
                SeisEvent tmp = new SeisEvent(rs.getInt(1));
                Date dd = null;
                
                try {
                   dd = df.parse(rs.getString(2));
                } catch (ParseException e)
                {
                    return false;
                }

                tmp.setOrigTime(dd);
                tmp.setLat(rs.getDouble(3));
                tmp.setLon(rs.getDouble(4));
                
                seisEvents.add(tmp);
            }

        } catch (SQLException ex) {
            return false;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (con != null) {
                    con.close();
                }

            } catch (SQLException ex) {
                
                return false;
            }
        }
        
        return !seisEvents.isEmpty();
    }
    
    /**as the list is not big, so use iteration to fill the events number
     * @param bList the blocklist to fill the events number
     * @return */
    public static boolean retrieveBlockEventNumber(ArrayList<TaskBlock> bList) {
                
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
             
        String query = "select ba.block_id, count(*)" +
                " From block_allocation ba, event_allocation ev" +
                " WHERE ba.id = ev.block_allocation_id AND ba.pass= 'p'" +
                " GROUP BY ba.block_id;"; 

        try {
            con = DriverManager.getConnection(url, user, password);
            st = con.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                
                for(TaskBlock tb:bList)
                {
                    //System.out.println(tb.getBlockID());
                    //System.out.println(rs.getInt(1));
                    
                    if(tb.getBlockID().equals(rs.getInt(1)))
                    {
                        tb.setEventNumber(rs.getInt(2));
                    }
                }
                
            }

        } catch (SQLException ex) {
            return false;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (con != null) {
                    con.close();
                }

            } catch (SQLException ex) {
                
                return false;
            }
        }
        
        return true;
    }
    
    /**The
     * 
     * @return */
    public static boolean retrieveBlockReviewedEventNumber(ArrayList<TaskBlock> bList) {
                
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
             
        String query = "select ba.block_id, count(*)" +
                " From block_allocation ba, event_allocation ev" +
                " WHERE ba.id = ev.block_allocation_id AND ba.start IS NOT NULL AND ba.finish IS NULL and ev.start IS NOT NULL" +
                " GROUP BY ba.block_id;"; 

        try {
            con = DriverManager.getConnection(url, user, password);
            st = con.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                
                for(TaskBlock tb:bList)
                {
                    //System.out.println(tb.getBlockID());
                    //System.out.println(rs.getInt(1));
                    
                    if(tb.getBlockID().equals(rs.getInt(1)))
                    {
                        tb.setEventNumber(rs.getInt(2));
                    }
                }
                
            }

        } catch (SQLException ex) {
            return false;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (con != null) {
                    con.close();
                }

            } catch (SQLException ex) {
                
                return false;
            }
        }
        
        return true;
    }
    
    public static int retrieveNewBlockID() {
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
             
        int newID = 0;
        
        String query = "SELECT NEXTID('id','block')";
        
        try {
            con = DriverManager.getConnection(url, user, password);
            st = con.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
            
                newID = rs.getInt(1);
            }
        }catch (SQLException ex) {
            
            } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (con != null) {
                    con.close();
                }

            } catch (SQLException ex) {
                
            }
                    
        }
        
        return newID;        
            
    }
    
     /**
     * change this
     * @param seisEvents to save all unallocated events to show on timeline and map
     * @param startDay selected startday
     * @param endDay selected endday
     * @param timeAndGeo
     * @param tb
     * @return success or not
     */
    public static boolean createBlock(ArrayList<SeisEvent> seisEvents, Date startDay, Date endDay, boolean timeAndGeo, TaskBlock tb)
    {
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        int blockID = tb.getBlockID();
        int allocID1 = 0, allocID2 = 0, allocID3 = 0;
        int selectID = 0;
        int regionID = 0;
                
        try {
            con = DriverManager.getConnection(url, user, password);
            con.setAutoCommit(false);
            
            st = con.createStatement();
            rs = st.executeQuery("SELECT NEXTID('selectid','block');");
            if (rs.next()) {
                selectID = rs.getInt(1);
            }
            rs.close();       
            
            //st = con.createStatement();
            rs = st.executeQuery("SELECT NEXTID('region_id','block');");
            if (rs.next()) {
                regionID = rs.getInt(1);
            }
            rs.close();
            System.out.println(regionID);          
            
            /*update block table*/
            //st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            PreparedStatement st1 = con.prepareStatement("INSERT INTO block VALUES (?,?,?,?,?)");
            st1.setInt(1,blockID);
            st1.setInt(2, selectID);
            st1.setTimestamp(3, new Timestamp(startDay.getTime()));
            st1.setTimestamp(4, new Timestamp(endDay.getTime()));
            st1.setInt(5, regionID);
            st1.executeUpdate();
           
            //con.commit();
            //rs.close();
            /*update first row of blockallocation the p pass*/
            rs = st.executeQuery("SELECT NEXTID('id','block_allocation');");
            while (rs.next()) {
                allocID1 = rs.getInt(1);
            }
            rs.close();
            System.out.println(allocID1);
            
            String sql2 = "INSERT INTO block_allocation "
                    + "(id, block_id, analyst_id, pass, planned_start, planned_finish, review) "
                    + "VALUES (?,?,?,?,?,?,?)";
            PreparedStatement st2 = con.prepareStatement(sql2);
            
            st2.setInt(1,allocID1);
            st2.setInt(2, blockID);
            st2.setInt(3, tb.getAnalyst1ID());
            st2.setString(4, "p");
            st2.setTimestamp(5, new Timestamp(tb.getPPlanStartDay().getTime()));
            st2.setTimestamp(6, new Timestamp(tb.getPPlanEndDay().getTime()));
            st2.setInt(7, 0);
            st2.executeUpdate();
            
            /*second row in the block_allocation table the s pass*/
            rs = st.executeQuery("SELECT NEXTID('id','block_allocation');");
            while (rs.next()) {
                allocID2 = rs.getInt(1);
            }
            rs.close();
            System.out.println(allocID2);
            
            String sql3 = "INSERT INTO block_allocation "
                    + "(id, block_id, analyst_id, pass, planned_start, planned_finish, review) "
                    + "VALUES (?,?,?,?,?,?,?)";
            PreparedStatement st3 = con.prepareStatement(sql3);
            
            st3.setInt(1,allocID2);
            st3.setInt(2, blockID);
            st3.setInt(3, tb.getAnalyst2ID());
            st3.setString(4, "s");
            st3.setTimestamp(5, new Timestamp(tb.getSPlanStartDay().getTime()));
            st3.setTimestamp(6, new Timestamp(tb.getSPlanEndDay().getTime()));
            st3.setInt(7, 0);
            st3.executeUpdate();
            
            /*third row in the block_allocation table the f pass*/
            rs = st.executeQuery("SELECT NEXTID('id','block_allocation');");
            while (rs.next()) {
                allocID3 = rs.getInt(1);
            }
            rs.close();
            System.out.println(allocID3);
            
            String sql4 = "INSERT INTO block_allocation "
                    + "(id, block_id, analyst_id, pass, planned_start, planned_finish, review) "
                    + "VALUES (?,?,?,?,?,?,?)";
            PreparedStatement st4 = con.prepareStatement(sql4);
            
            st4.setInt(1,allocID3);
            st4.setInt(2, blockID);
            st4.setInt(3, tb.getAnalyst3ID());
            st4.setString(4, "f");
            st4.setTimestamp(5, new Timestamp(tb.getFPlanStartDay().getTime()));
            st4.setTimestamp(6, new Timestamp(tb.getFPlanEndDay().getTime()));
            st4.setInt(7, 0);
            st4.executeUpdate();
            
            /*insert into the event_allocation table*/
            String sql5 = "INSERT INTO event_allocation "
                    + "(evid, block_allocation_id, block_selectid) "
                    + "VALUES (?,?,?)";
            PreparedStatement st5 = con.prepareStatement(sql5);
                        
            for(SeisEvent ev:seisEvents)
            {
                if(timeAndGeo == true)
                {
                    //both selected, commit into the database
                    if(ev.getTSelction()==true && ev.getGSelction()==true && ev.getblAssigned()!= true && blockID>0)
                    {
                        st5.setInt(1, ev.getEvid());
                        st5.setInt(2, allocID1);
                        st5.setInt(3, selectID);
                        st5.executeUpdate();
                        
                        st5.setInt(1, ev.getEvid());
                        st5.setInt(2, allocID2);
                        st5.setInt(3, selectID);
                        st5.executeUpdate();
                        
                        st5.setInt(1, ev.getEvid());
                        st5.setInt(2, allocID3);
                        st5.setInt(3, selectID);
                        st5.executeUpdate();
                    }
                }
                else
                {
                    //only commit for time
                    if(ev.getTSelction()==true && ev.getblAssigned()!= true && blockID>0)
                    {
                        st5.setInt(1, ev.getEvid());
                        st5.setInt(2, allocID1);
                        st5.setInt(3, selectID);
                        st5.executeUpdate();
                        
                        st5.setInt(1, ev.getEvid());
                        st5.setInt(2, allocID2);
                        st5.setInt(3, selectID);
                        st5.executeUpdate();
                        
                        st5.setInt(1, ev.getEvid());
                        st5.setInt(2, allocID3);
                        st5.setInt(3, selectID);
                        st5.executeUpdate();                     
                    }
                }
            }
                        
            con.commit();
            st1.close();
            st2.close();
            st3.close();
            st4.close();
            st5.close();
         
        } catch(SQLException e) {
            try {
                con.rollback();
            } catch(SQLException e2)
            {
                System.out.println("Rollback failure ");
            }
            return false;
        }
        finally {
            try {
                if (rs != null) {
                    rs.close();
                }

                if (st != null) {
                    st.close();
                }
                if (con != null) {
                    con.close();
                }

            } catch (SQLException ex) {
                
                return false;
            }
        }
        
        return true;
    }

    public static boolean loadBlocks(HashSet<TaskBlock> blockSet) {
       
        //clear the memory of blockArray in order to reload events
        //blockArray.clear();
        
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        
        String query = "SELECT b.id, b.starttime, b.endtime, b.region_id, a.name, ba.pass, ba.review" +
                " FROM block b, block_allocation ba, analyst a" +
                " Where b.id = ba.block_id AND a.id = ba.analyst_id" +
                " ORDER BY b.id, ba.pass;";

        try {
            con = DriverManager.getConnection(url, user, password);
            st = con.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                
                if(blockSet.contains(new TaskBlock(rs.getInt(1))))
                {
                    for (TaskBlock obj : blockSet) {
                        if (obj.getBlockID().equals(rs.getInt(1))) 
                        {
                            if("p".equals(rs.getString(6)))
                            {
                                obj.setAnalyst1(rs.getString(5));
                                if(rs.getInt(7)==0)
                                {
                                    obj.setStatus("P");
                                }
                            }
                            else if("s".equals(rs.getString(6)))
                            {
                                obj.setAnalyst2(rs.getString(5));
                                if(obj.getStatus()==null && rs.getInt(7)==0)
                                {
                                    obj.setStatus("S");
                                }
                            }
                            else if("f".equals(rs.getString(6)))
                            {
                                obj.setAnalyst3(rs.getString(5));
                                if(obj.getStatus()==null && rs.getInt(7)==0)
                                {
                                    obj.setStatus("F");
                                }
                                else
                                {
                                    obj.setStatus("Done");
                                }
                            }
                        }
                    } 
                }
                else
                {
                    TaskBlock tmp = new TaskBlock(rs.getInt(1));

                    tmp.setStartDay(new Date(rs.getTimestamp(2).getTime()));
                    tmp.setEndDay(new Date(rs.getTimestamp(3).getTime()));
                    tmp.setRegionID(rs.getInt(4));
                    
                    if("p".equals(rs.getString(6)))
                    {
                        tmp.setAnalyst1(rs.getString(5));
                        if(rs.getInt(7)==0)
                        {
                            tmp.setStatus("P");
                        }
                    }
                    else if("s".equals(rs.getString(6)))
                    {
                        tmp.setAnalyst2(rs.getString(5));
                        if(rs.getInt(7)==0)
                        {
                            tmp.setStatus("S");
                        }
                    }
                    else if("f".equals(rs.getString(6)))
                    {
                        tmp.setAnalyst3(rs.getString(5));
                        if(rs.getInt(7)==0)
                        {
                            tmp.setStatus("F");
                        }
                        else
                        {
                            tmp.setStatus("Done");
                        }
                    }
                    
                    blockSet.add(tmp);
                }
            }

        } catch (SQLException ex) {
            return false;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (con != null) {
                    con.close();
                }

            } catch (SQLException ex) {
                
                return false;
            }
        }
        
        return true;
    }
    
 public static String[] loadEmails() {
        
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        
        ArrayList<String> emails = new ArrayList<>();
        
        String query = "SELECT email FROM analyst;";
        
        try {
            con = DriverManager.getConnection(url, user, password);
            st = con.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                emails.add(rs.getString(1));
            }            
        } 
        catch (SQLException ex) {
            return null;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (con != null) {
                    con.close();
                }

            } catch (SQLException ex) {
                
                return null;
            }
        }
        
        String[] retEmails = emails.toArray(new String[emails.size()]);
        
        return retEmails;
    }
 
    public static boolean loadAnslysts(ArrayList<Analyst> anList) {
        
        Connection con = null;
        Statement st = null;
        ResultSet rs = null;
        
        
        String query = "SELECT id, name, email, position FROM analyst;";
        
        try {
            con = DriverManager.getConnection(url, user, password);
            st = con.createStatement();
            rs = st.executeQuery(query);

            while (rs.next()) {
                
                Analyst an = new Analyst(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
                anList.add(an);
            }            
        } 
        catch (SQLException ex) {
            return false;
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (con != null) {
                    con.close();
                }

            } catch (SQLException ex) {                
                return false;
            }
        }
        
        return true;
    }

    public static boolean deleteBlock(int bid) {
        Connection con = null;
        Statement st = null;
        
        String q1 = "DELETE FROM block b WHERE b.id = " + bid;
        String q2 = "DELETE FROM event_allocation ea WHERE ea.block_allocation_id" +
                 " IN ( SELECT ba.id FROM block_allocation ba WHERE ba.block_id = " + bid + ")";
        String q3 = "DELETE FROM block_allocation ba WHERE ba.block_id = " + bid;
        
        try {
            con = DriverManager.getConnection(url, user, password);
            con.setAutoCommit(false);
        
            st = con.createStatement();
            st.executeUpdate(q1);
            st.executeUpdate(q2);
            st.executeUpdate(q3);
            
            con.commit();
        }  catch (SQLException ex) {                
                return false;
        }
        
        return true;
    }

}