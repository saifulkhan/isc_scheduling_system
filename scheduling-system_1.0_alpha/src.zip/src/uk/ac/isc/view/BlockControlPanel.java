
package uk.ac.isc.view;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.UIManager;
import uk.ac.isc.data.SeisEvent;
import uk.ac.isc.data.SeisEventList;
import uk.ac.isc.data.SeisEventsDAO;


/**
 * this panel has several buttons to control the information showing
 * in the figures in the blockinfopanel and activate the assignment panel.
 * 
 * @author hui
 */
public class BlockControlPanel extends JPanel {
   
    /** Here are the data*/
    private final Date startDate;
    
    private final Date endDate;
    
    private final SeisEventList seList;
    
    /*controllers*/
    private final JButton newButton = new JButton("New");
    
    private final JButton deleteButton = new JButton("Delete");
    
    private final JButton mergeButton = new JButton("Merge");
    
    private final JButton emailButton = new JButton("Email");
    
    private final JLabel breakLabel = new JLabel("            ");
    
    private final JLabel viewLabel = new JLabel("View:");
    
    private final JRadioButton blockViewButton = new JRadioButton("Blocks");
    
    private final JRadioButton analystViewButton = new JRadioButton("Analysts");
    
    private final ButtonGroup bg = new ButtonGroup();
    
    /*referenct to blockinfo panel for setting the flags*/
    private final BlockInfoPanel biPanel;
    
    public BlockControlPanel(Date startDate, Date endDate, SeisEventList allEvents, BlockInfoPanel biPanel)
    {
        this.startDate = startDate;
        this.endDate = endDate;
        this.seList = allEvents;
        
        this.biPanel = biPanel;
        
        this.setLayout(new FlowLayout());
        
        newButton.setPreferredSize(new Dimension(200,40));
        deleteButton.setPreferredSize(new Dimension(200,40));
        mergeButton.setPreferredSize(new Dimension(200,40));
        emailButton.setPreferredSize(new Dimension(200,40));
        
        this.add(newButton);
        this.add(deleteButton);
        this.add(mergeButton);
        this.add(emailButton);
        
        /*start addding action listener for the four buttons*/
        newButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AssignMainPanel amp = new AssignMainPanel(startDate, endDate, seList);
                String[] options = {"OK"};
                UIManager.put("OptionPane.minimumSize", new Dimension(1250,850));
                int result = JOptionPane.showOptionDialog(null, amp, "Create Blocks by grouping unassigned events", 
                        JOptionPane.NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options , options[0]);
                //if (result == JOptionPane.OK_OPTION) {
            }
        });
        
        deleteButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {

                int bid = biPanel.getSBid();
                
                //System.out.println(biPanel.getBlockStatus());
                if("S".equals(biPanel.getBlockStatus())|| "F".equals(biPanel.getBlockStatus()))
                {
                    JOptionPane.showMessageDialog(null,
                        "The block has been reviewed which cannot be deleted.\n"
                                + "Please contact with the data administrator for more options",
                            "Inane error",
                    JOptionPane.ERROR_MESSAGE);
                }
                else
                {
                    SeisEventsDAO.deleteBlock(bid);
                    biPanel.getTableModel().fireTableRowsDeleted(bid, bid);
                    
                    for(SeisEvent se:seList.getSeisEvents())
                    {
                        if(se.getBlockID()!=null && se.getBlockID()==bid)
                        {
                            se.setblAssigned(false);
                            se.setBlockID(null);
                        }
                    }
                }
            }
        });
        
        emailButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                EmailPanel ePanel = new EmailPanel();
                 UIManager.put("OptionPane.minimumSize", new Dimension(250,600));               
                int result = JOptionPane.showConfirmDialog(null, ePanel, "Sending Message",JOptionPane.OK_CANCEL_OPTION);
                if (result == JOptionPane.OK_OPTION) {
                    //System.out.println("Sending messages to "+ (String)analystList.getSelectedItem());
                    String host = "192.168.37.85";
                    //Map<String, String> env = System.getenv();
                    //String from = env.get("PGUSER");
                    String from = "Hui";
                    String to = ePanel.getRecipient();
                    
                    Properties properties = System.getProperties();
                    properties.setProperty("mail.smtp.host", host);  
                    Session session = Session.getDefaultInstance(properties);  
                    try{
                        // Create a default MimeMessage object.
                        MimeMessage message = new MimeMessage(session);

                        // Set From: header field of the header.
                        message.setFrom(new InternetAddress(from));

                        // Set To: header field of the header.
                         message.addRecipient(Message.RecipientType.TO,
                                  new InternetAddress(to));

                        // Set Subject: header field
                        message.setSubject(ePanel.getTopic());

                        // Now set the actual message
                        message.setText(ePanel.getMessage());

                        // Send message
                        Transport.send(message);
                        //System.out.println("Sent message successfully....");
                    }catch (MessagingException mex) {
                         mex.printStackTrace();
                    }
                }
            }
        });
          
        blockViewButton.setSelected(true);
        bg.add(blockViewButton);
        bg.add(analystViewButton);
        
        blockViewButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                biPanel.setViewFlag(0);
                //blockViewButton.setSelected(true);
            }
        });
        
        analystViewButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                biPanel.setViewFlag(1);
                //analystViewButton.setSelected(true);
            }
        });
        
        this.add(breakLabel);
        this.add(viewLabel);
        this.add(blockViewButton);
        this.add(analystViewButton);   
        
    }
    
}
