
package uk.ac.isc.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Paint;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import javax.swing.JPanel;
import uk.ac.isc.data.TaskBlock;

/**
 *
 * @author hui
 */
public class BlockVisPanel extends JPanel {
     
    private final ArrayList<TaskBlock> bList;
    
    /*every 100 events, 5 pixel is showed*/
    private final double pixelPerUnit = 0.1;
    
    private final double blockHeight = 30;
    
    private final int blockInterval = 40;
    
    private final Color pColor = Color.BLUE;
    
    private final Color sColor = Color.RED;
    
    private final Color fColor = Color.GREEN;
    
    public BlockVisPanel(ArrayList<TaskBlock> bList)
    {
        this.bList = bList;
        
    }
    
      @Override
    protected void paintComponent(Graphics g) {
    
        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g.create();
        //Dimension size = getSize();
        //Insets insets = getInsets();
        //Rectangle2D available = new Rectangle2D.Double(insets.left, insets.top,
        //        size.getWidth() - insets.left - insets.right,
        //        size.getHeight() - insets.top - insets.bottom);
        //double drawWidth = available.getWidth();
        //double drawHeight = available.getHeight();
        Paint savedColor = g2.getPaint();
        
        for(int i = 0; i<bList.size(); i++)
        {
            double startX = 100;
            double startY = (i+1)*blockInterval;
            double width = bList.get(i).getEventNumber()*pixelPerUnit;
            
            Rectangle2D blockBar = new Rectangle2D.Double(startX, startY, width, blockHeight);
            if("P".equals(bList.get(i).getStatus()))
            {
                g2.setPaint(pColor);
            }
            else if("S".equals(bList.get(i).getStatus()))
            {
                g2.setPaint(sColor);
            }
            else if("F".equals(bList.get(i).getStatus()))
            {
                g2.setPaint(fColor);
            }
            
            g2.fill(blockBar);
        }
        
    }
}
